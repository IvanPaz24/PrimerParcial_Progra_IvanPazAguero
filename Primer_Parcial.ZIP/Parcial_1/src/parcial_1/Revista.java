/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package parcial_1;

/**
 *
 * @author ivan_
 */
public class Revista extends Publicacion implements Leibles{
    private int numeroEdicion;
    public Revista(int numeroEdicion, String titulo, String anioPublicacion) {
        super(titulo, anioPublicacion);
        this.numeroEdicion = numeroEdicion;
    }
    
    @Override
    public void leer(){
        System.out.println("Leyendo revista: " + getTitulo());
    }

    @Override
    public String toString() {
        return "Revista{" + "numeroEdicion=" + numeroEdicion + '}';
    }
    
    
}
