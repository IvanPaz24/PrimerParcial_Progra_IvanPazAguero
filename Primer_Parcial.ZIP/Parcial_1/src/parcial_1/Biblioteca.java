/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package parcial_1;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author ivan_
 */
public class Biblioteca {
    private String nombre;
    private List<Publicacion> publicaciones;

    public Biblioteca(String nombre) {
        this.nombre = nombre;
        this.publicaciones = new ArrayList<>();
    }
    
    public void agregarPublicaciones(Publicacion p){
        // verificaciones que no pasen datos errones
        if (p== null) {
            throw new NullPointerException();
        }
        
        if (buscarPublicacion(p)) {
            throw new PublicacionesIgualesExeption();
        }
        //si el dato es coorecto se agrega a la lista
        publicaciones.add(p);
    }
    
    //metodo privado que busca en la lista una publicacion repetida
    private boolean buscarPublicacion(Publicacion pub){
        boolean flag = false; 
        for (Publicacion p : publicaciones) {
            if (p.equals(pub)) {
                flag = true;
            }
        }
        return flag;
    }

    public void mostrarPublicaciones(){
        for (Publicacion p: publicaciones) {
            System.out.println(p);
        }
    }
    
    public void leerPublicaciones(){
        for (Publicacion p: publicaciones) {
            if (p instanceof Leibles) {// en caso de ser leible muestra el mensaje
                ((Leibles) p).leer();//casteo libro o revista
            }
            else{
                System.out.println("No se puede leer");// si no es leible
            }
        }
        
//        for (Publicacion p: publicaciones) {
//            if (p instanceof Libro) {
//                p.leer();
//            }else{
//                if (p instanceof Revista) {
//                    p.leer();
//                }
//                else{
//                    System.out.println("No se puede leer");
//                }
//            }
//        }
    }
}
