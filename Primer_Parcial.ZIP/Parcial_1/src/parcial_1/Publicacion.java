/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package parcial_1;

import java.util.Objects;

/**
 *
 * @author ivan_
 */
public abstract class Publicacion {
    private String titulo;
    private String anioPublicacion;

    public Publicacion(String titulo, String anioPublicacion) {
        this.titulo = titulo;
        this.anioPublicacion = anioPublicacion;
    }

    public String getTitulo() {
        return titulo;
    }
    
    
    
    //public void leer(){
        
    //}
    
    public boolean equals(Object o){
        if (this == o) {
            return true;
        }
        if (o == null || o.getClass() != getClass()) {
            return false;
        }
        
        Publicacion other = (Publicacion) o;
        //en caso de tener titulo y anio igual retorna true
        return titulo.equals(other.titulo) && anioPublicacion.equals(other.anioPublicacion);
    }

    @Override
    public int hashCode() {
        return Objects.hash(titulo, anioPublicacion);
    }
    
    
    
}
