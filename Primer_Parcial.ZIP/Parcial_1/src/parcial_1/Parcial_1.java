/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package parcial_1;

/**
 *
 * @author ivan_
 */
public class Parcial_1 {


    public static void main(String[] args) {
        Biblioteca b = new Biblioteca("Libros");
        Libro l = new Libro("Pepe", Genero.HISTORIA, "Historia", "1999");
        Libro l2 = new Libro("Pepe", Genero.HISTORIA, "Historia", "1999");
        Revista r = new Revista(5, "Pasteles", "2020");
        Revista r2 = new Revista(5, "Historia", "1999");
        Ilustracion i = new Ilustracion("Picasso", 10, 10, "Pintura", "1888");
        
        //carga de datos
        try {
            b.agregarPublicaciones(l);
            b.agregarPublicaciones(r);
            b.agregarPublicaciones(i);
            //b.agregarPublicaciones(l);
            
        } catch (NullPointerException e) {
            System.out.println("Me pasaste una publicacion vacia");
        }catch (PublicacionesIgualesExeption ex){
            System.out.println("Publicacion repetida");
        }
        
        b.mostrarPublicaciones();
        
        b.leerPublicaciones();
        
        //prueba de errores
        try {
            //revista y libro con titulo y anioSimilar
            b.agregarPublicaciones(l2);
            b.agregarPublicaciones(r2);
            // libros similares
            b.agregarPublicaciones(l);
            b.agregarPublicaciones(l2);
            //dato nulo
            //b.agregarPublicaciones(null);
            //b.agregarPublicaciones(i);
            //b.agregarPublicaciones(l);
            
        } catch (NullPointerException e) {
            System.out.println("Me pasaste una publicacion vacia");
        }catch (PublicacionesIgualesExeption ex){
            System.out.println("Publicacion repetida");
        }
        
    }
    
}
