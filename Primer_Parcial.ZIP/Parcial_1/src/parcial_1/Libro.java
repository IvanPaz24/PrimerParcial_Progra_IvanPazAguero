/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package parcial_1;

/**
 *
 * @author ivan_
 */
public class Libro extends Publicacion implements Leibles{
    
    private String autor;
    private Genero genero;
    public Libro(String autor, Genero genero, String titulo, String anioPublicacion) {
        super(titulo, anioPublicacion);
        this.autor = autor;
        this.genero = genero;
    }
    
    @Override
    public void leer(){
        System.out.println("Leyendo libro: "+ getTitulo());
    }

    @Override
    public String toString() {
        return "Libro{" + "autor=" + autor + ", genero=" + genero + '}';
    }
    
    
    
}
