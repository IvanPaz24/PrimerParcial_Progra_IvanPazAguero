/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package parcial_1;

/**
 *
 * @author ivan_
 */
public class Ilustracion extends Publicacion{
    
    private String nombreIlistrador;
    private int alto;
    private int ancho;
    public Ilustracion(String nombreIlustrador, int alto, int ancho, String titulo, String anioPublicacion) {
        super(titulo, anioPublicacion);
        this.nombreIlistrador = nombreIlustrador;
        this.alto = alto;
        this.ancho = ancho;
    }

    // @Override
    //public void leer() {

    //}

    @Override
    public String toString() {
        return "Ilustracion{" + "nombreIlistrador=" + nombreIlistrador + ", alto=" + alto + ", ancho=" + ancho + '}';
    }
    
    
}
