/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package parcial_1;

/**
 *
 * @author ivan_
 */
public interface Leibles {
    public abstract void leer();
}
