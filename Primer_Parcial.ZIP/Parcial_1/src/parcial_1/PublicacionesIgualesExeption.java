/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package parcial_1;

/**
 *
 * @author ivan_
 */
public class PublicacionesIgualesExeption extends RuntimeException{
    public final static String MASSAGE = "El libro ya existe";
    
    public PublicacionesIgualesExeption(){
        super(MASSAGE);
    }
    
}
